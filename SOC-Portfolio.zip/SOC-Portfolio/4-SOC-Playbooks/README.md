# 4-SOC-Playbooks

Purpose: Provide short, actionable playbooks and templates for common incidents.

Folders:
- `playbooks/` — playbook markdown files (bruteforce, phishing, malware)
- `templates/` — incident report and ticket templates

Open `playbooks/playbook_bruteforce.md` for the sample workflow.
