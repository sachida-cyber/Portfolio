# Incident Report Template

- Incident ID:
- Date/time:
- Affected asset(s):
- Detection source:
- Summary:
- Actions taken (containment):
- Escalation (L2 / IR team):
- Recovery actions:
- Lessons learned / next steps:
